import java.util.*;
public class Switch {
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		char choice = in.next().charAt(0);
		in.close();
		switch(choice) {
		case 'A': System.out.println("Action movie fan\n");
				  break;
		case 'a': System.out.println("Action movie fan\n");
		  		  break;
		case 'C': System.out.println("Comedy movie fan\n");
				  break;
		case 'c': System.out.println("Comedy movie fan\n");
		  		  break;
		case 'D': System.out.println("Drama movie fan\n");
		  		  break;
		case 'd': System.out.println("Drama movie fan\n");
		  		  break;
  		default: System.out.println("Invalid choice\n");
		}

	}
}
