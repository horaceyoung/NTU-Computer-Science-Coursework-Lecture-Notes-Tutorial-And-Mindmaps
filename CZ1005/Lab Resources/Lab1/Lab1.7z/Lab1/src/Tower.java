import java.util.*;
public class Tower {
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		int height = in.nextInt();
		String patternA = "AA";
		String patternB = "BB";
		String result = "";
		for (int i = 1; i<=height;i++) {
			for (int j=1;j<=i;j++) {
				if(j%2==1) {
					result = result + patternA;
				}
				else {
					result = result + patternB;
				}

			}
			System.out.println(result);
			result = "";
		}
	}
}
