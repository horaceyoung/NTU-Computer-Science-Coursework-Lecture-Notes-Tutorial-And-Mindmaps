import java.util.*;
public class Currency {
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		int start, end, increment;
		start = in.nextInt();
		end = in.nextInt();
		increment = in.nextInt();
		while(start<=end) {
			System.out.format("%d %10.2f\n", start, start*1.82);
			start+=increment;
		}
	}
	
}
