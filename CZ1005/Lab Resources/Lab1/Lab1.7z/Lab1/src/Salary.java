import java.util.*;
public class Salary {
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		int salary, merit;
		salary = in.nextInt();
		merit = in.nextInt();
		while(salary >0) {
			if (salary >=500 && salary <600) {
				System.out.println("Grade C");
			}
			else if (salary >=600 && salary <=649) {
				if (merit<10) {
					System.out.println("Grade C");
				}
				else {System.out.println("Grade B");}
			}
			else if (salary>=700 && salary<=799) {
				if (merit<20) {
					System.out.println("Grade B");
				}
				else System.out.println("Grade A");
			}
			else if (salary >799) {
				System.out.println("Grade A");
			}
			salary = in.nextInt();
			merit = in.nextInt();
		}
	}
}
